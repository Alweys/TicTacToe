﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;

namespace TicTacToe_Server
{
    public partial class Form1 : Form
    {
        Int32 port = 50000;
        static string IP = "127.0.0.1";
        //static string IP = "192.168.43.50";
        //static string IP = "192.168.1.11";
        IPAddress localAddr = IPAddress.Parse(IP);
        bool server_started = false;
        TcpListener server = null;
        Thread server_thread;
        Thread game_thread;
        static int maxClients = 10;
        int playersTeam1 = 0;
        int playersTeam2 = 0;
        public enum Token { X, O, Empty }
        public Token[,] _board = new Token[3, 3];
        struct GameInfo
        {
            public int id;
            public int playerID1;
            public int playerID2;
            public bool setTurn;
            public Thread[] threads;
            public int playerTurn;
            public int playerTurnX;
            public int playerTurnO;
            public bool game_started;
            public Token[,] _board;
        }

        struct ClientInfo
        {
            public int id;
            public int gameID;
            public int opponentID;
            public NetworkStream stream;
            public bool ready;
            public bool connected;
            public bool inGame;
            public string name;
            public bool Pota;
            public bool verified;
            public int tim;
            public int teamID;
        };

        int connected_clients = 0;

        Thread[] threadsArray = new Thread[maxClients + 1];
        ClientInfo[] clients = new ClientInfo[maxClients + 1];
        GameInfo[] games = new GameInfo[(maxClients / 2) + 1];
        GameInfo game = new GameInfo();
        int started_games = 0;

        void init()
        {
            connected_clients = 0;
            for (int i = 1; i < clients.Length; i++)
            {
                clients[i].id = -1;
                clients[i].gameID = -1;
                clients[i].opponentID = -1;
                clients[i].name = "";
                clients[i].ready = false;
                clients[i].inGame = false;
                clients[i].Pota = false;
                clients[i].verified = false;
                clients[i].tim = -1;
                clients[i].teamID = -1;
            }
            for (int i = 0; i < games.Length; i++)
            {
                games[i].id = -1;
                games[i]._board = new Token[3, 3];
                games[i].threads = new Thread[maxClients / 2];
                games[i].game_started = false;
                games[i].playerTurn = -1;
                games[i].playerTurnX = -1;
                games[i].playerTurnO = -1;
                games[i].playerID1 = -1;
                games[i].playerID2 = -1;
                games[i].setTurn = false;
                for (int j = 0; j < 3; j++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        games[i]._board[j, k] = Token.Empty;
                    }
                }
            }

            game.id = -1;
            game._board = new Token[3, 3];
            game.game_started = false;
            game.playerTurn = -1;
            game.setTurn = false;
            for (int j = 0; j < 3; j++)
            {
                for (int k = 0; k < 3; k++)
                {
                    game._board[j, k] = Token.Empty;
                }
            }

            /*
            player1status.Text = "Not connected";
            player2status.Text = "Not connected";
            readyPlayer1.Text = "No";
            readyPlayer2.Text = "No";*/
        }

        void updateClientList()
        {
            clientListPanel.Invoke((MethodInvoker)(() => clientListPanel.Controls.Clear()));
            for (int i = 1; i < maxClients + 1; i++)
            {
                if (clients[i].connected)
                {
                    Label textControl = new Label();
                    textControl.AutoSize = true;
                    textControl.Text = "[" + i + "]:    ";
                    textControl.Text += clients[i].name + "    ";
                    if (clients[i].ready)
                        textControl.Text += "Ready" + "    ";
                    else
                        textControl.Text += "Not Ready" + "    ";
                    //if (clients[i].inGame)
                    //    textControl.Text += "In Game" + "    ";
                    //else
                    //    textControl.Text += "Not In Game" + "    ";
                    textControl.Text += "Team: " + clients[i].tim + "    ";
                    textControl.Text += "Team ID: [" + clients[i].teamID + "]    ";
                    textControl.Location = new Point(5, 5 + (i * 15));
                    clientListPanel.Invoke((MethodInvoker)(() => clientListPanel.Controls.Add(textControl)));
                }
            }
        }

        void updateGameList()
        {
            Font MediumFont = new Font("Courier", 15);
            Font LargeFont = new Font("Courier", 20);
            gameListPanel.Invoke((MethodInvoker)(() => gameListPanel.Controls.Clear()));
            //for (int i = 0; i < games.Length; i++)
            {
                if (game.game_started)
                {
                    Label textControl = new Label();
                    textControl.AutoSize = true;
                    textControl.Text = "Game [" + game.id + "]:    ";
                    textControl.Text += "Turn: [" + game.playerTurnO + "]    ";
                    textControl.Text += "Turn: [" + game.playerTurnX + "]    ";
                    textControl.Location = new Point(5, 5 + (0 * 15));
                    gameListPanel.Invoke((MethodInvoker)(() => gameListPanel.Controls.Add(textControl)));
                    int index = -1;
                    gameSelection.Invoke((MethodInvoker)(() => index = gameSelection.SelectedIndex));
                    //if (index == i)
                    {
                        string board = "";
                        for (int k = 0; k < game._board.GetLength(0); k++)
                        {
                            for (int j = 0; j < game._board.GetLength(1); j++)
                            {
                                if (!game._board[k, j].Equals(Token.Empty))
                                    board += (game._board[k, j] + " ");
                                else
                                    board += ("  ");
                            }
                            board += "\n";
                        }
                        gamePreview.Invoke((MethodInvoker)(() => gamePreview.Font = LargeFont));
                        gamePreview.Invoke((MethodInvoker)(() => gamePreview.Text = board));
                    }
                }
                else
                {
                    int index = -1;
                    gameSelection.Invoke((MethodInvoker)(() => index = gameSelection.SelectedIndex));
                    //if (index == i)
                    {
                        gamePreview.Invoke((MethodInvoker)(() => gamePreview.Font = MediumFont));
                        gamePreview.Invoke((MethodInvoker)(() => gamePreview.Text = "Game not started"));
                    }
                }
            }
        }

        public class Item
        {
            public Item() { }

            public string Value { set; get; }
            public string Text { set; get; }
        }
        public Form1()
        {
            InitializeComponent();
            this.Text = "TicTacToe Server";
            init();
            game_thread = new Thread(mainGame);
            game_thread.IsBackground = true;
            game_thread.Start();
            button3.Visible = false;
            button4.Visible = false;
            playerturnlabel.Visible = false;
            label10.Visible = false;
            List<Item> items = new List<Item>();
            for (int i = 0; i < games.Length - 1; i++)
            {
                items.Add(new Item() { Text = "Game " + i, Value = "" + i });
            }

            gameSelection.DataSource = items;
            gameSelection.DisplayMember = "Text";
            gameSelection.ValueMember = "Value";

        }

        void mainGame()
        {
            while (true)
            {
                /*for (int i = 1; i < clients.Length; i++)
                {
                    Console.WriteLine("[" + i + "] " + clients[i].id);
                    Thread.Sleep(1000);
                }*/
                bool sviReady = false;
                if (connected_clients > 1)
                {
                    sviReady = true;
                    for (int i = 1; i < connected_clients + 1; i++)
                    {
                        if (!clients[i].ready)
                            sviReady = false;
                    }
                }

                if (game.id == -1 && !game.game_started)
                {
                    if(sviReady)
                    {
                        game.id = 1;
                        game.setTurn = true;
                    }
                }

                if (sviReady && connected_clients > 1)
                {
                    if (!game.game_started)
                    {
                        if (game.setTurn)
                        {
                            playersTeam1 = 0;
                            playersTeam2 = 0;
                            for (int j = 1; j < connected_clients; j++)
                            {
                                if (clients[j].tim == 1)
                                    playersTeam1++;
                                if (clients[j].tim == 2)
                                    playersTeam2++;
                            }
                            listBox1.Invoke((MethodInvoker)(() => listBox1.Items.Add("Set turn for game")));
                            listBox1.Invoke((MethodInvoker)(() => listBox1.SelectedIndex = listBox1.Items.Count - 1));
                            Random rand = new Random();
                            game.playerTurnO = rand.Next(1, playersTeam1);
                            game.playerTurnX = rand.Next(1, playersTeam2);
                            game.setTurn = false;
                            for (int i = 1; i < connected_clients + 1; i++)
                            {
                                if(clients[i].connected && clients[i].verified)
                                {
                                    string textToSend = "turn=" + game.playerTurnO + "=" + game.playerTurnX;                               
                                    byte[] bytesToSend = ASCIIEncoding.ASCII.GetBytes(textToSend);
                                    clients[i].stream.Write(bytesToSend, 0, bytesToSend.Length);
                                    //Console.WriteLine("test");
                                }
                            }
                            game.game_started = true;
                        }
                    }
                    else if (game.game_started)
                    {
                        //Console.WriteLine("TEST");
                        if (HasWon(Token.O))
                        {
                            game.id = -1;
                            game.game_started = false;
                            for (int i = 1; i < connected_clients + 1; i++)
                            {
                                if (clients[i].connected && clients[i].verified)
                                {
                                    clients[i].ready = false;
                                    clients[i].inGame = false;
                                }
                            }
                            game.setTurn = true;
                            started_games--;
                            Console.WriteLine("Team 1 Won!");
                            int winnerID = 1;
                            //string textToSend = "winner=" + clients[winnerID].name;
                            string textToSend = "winner=" + winnerID;
                            byte[] bytesToSend = ASCIIEncoding.ASCII.GetBytes(textToSend);
                            for (int i = 1; i < connected_clients + 1; i++)
                                clients[i].stream.Write(bytesToSend, 0, bytesToSend.Length);
                            for (int j = 0; j < 3; j++)
                            {
                                for (int k = 0; k < 3; k++)
                                {
                                    game._board[j, k] = Token.Empty;
                                }
                            }
                            updateClientList();
                            updateGameList();
                        }
                        else if (HasWon(Token.X))
                        {
                            game.id = -1;
                            game.game_started = false;
                            for (int i = 1; i < connected_clients + 1; i++)
                            {
                                if (clients[i].connected && clients[i].verified)
                                {
                                    clients[i].ready = false;
                                    clients[i].inGame = false;
                                }
                            }
                            game.setTurn = true;
                            started_games--;

                            Console.WriteLine("Team 2 Won!");
                            int winnerID = 2;
                            //string textToSend = "winner=" + clients[winnerID].name;
                            string textToSend = "winner=" + winnerID;
                            byte[] bytesToSend = ASCIIEncoding.ASCII.GetBytes(textToSend);
                            for (int i = 1; i < connected_clients + 1; i++)
                                clients[i].stream.Write(bytesToSend, 0, bytesToSend.Length);

                            for (int j = 0; j < 3; j++)
                            {
                                for (int k = 0; k < 3; k++)
                                {
                                    game._board[j, k] = Token.Empty;
                                }
                            }
                            updateClientList();
                            updateGameList();
                        }
                    }
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!server_started)
            {
                label2.Text = "Waiting for a connection...";
                server_thread = new Thread(serverListen);
                server_thread.Start();
                server_started = true;
            }
        }

        public bool HasWon(Token token)
        {
            return IsHorizontalVictory(token) || IsVerticalVictory(token) || IsDiagonalVictory(token);
        }

        private bool IsHorizontalVictory(Token token)
        {
            for (int y = 0; y <= 2; y++)
            {
                if (game._board[0, y] == token && game._board[1, y] == token && game._board[2, y] == token)
                    return true;
            }

            return false;
        }

        private bool IsVerticalVictory(Token token)
        {
            for (int x = 0; x <= 2; x++)
            {
                if (game._board[x, 0] == token && game._board[x, 1] == token && game._board[x, 2] == token)
                    return true;
            }

            return false;
        }

        private bool IsDiagonalVictory(Token token)
        {
            if (game._board[0, 0] == token && game._board[1, 1] == token && game._board[2, 2] == token)
                return true;

            if (game._board[0, 2] == token && game._board[1, 1] == token && game._board[2, 0] == token)
                return true;

            return false;
        }
        int id1 = 1;
        int id2 = 1;
        void HandleClient(TcpClient obj)
        {
            Byte[] bytes = new Byte[256];
            String data = null;
            int thisClientId = -1;
            TcpClient client = obj;
            //stream = client.GetStream();
            if (client.Connected)
            {

                for (int j = 1; j < clients.Length; j++)
                {
                    if (clients[j].id == -1)
                    {
                        clients[j].id = j;
                        thisClientId = clients[j].id;
                        if (connected_clients % 2 == 0)
                            clients[thisClientId].tim = 1;
                        else
                            clients[thisClientId].tim = 2;
                        //thisClientId = connected_clients;
                        break;
                    }
                }
                try
                {
                    clients[thisClientId].stream = client.GetStream();
                    string textToSend = "id=" + thisClientId;
                    byte[] bytesToSend = ASCIIEncoding.ASCII.GetBytes(textToSend);
                    clients[thisClientId].stream.Write(bytesToSend, 0, bytesToSend.Length);
                }
                catch { }
                listBox1.Invoke((MethodInvoker)(() => listBox1.Items.Add("Client with id " + thisClientId + " connected to the Server!")));
                listBox1.Invoke((MethodInvoker)(() => listBox1.SelectedIndex = listBox1.Items.Count - 1));
                clients[thisClientId].connected = true;
                clients[thisClientId].id = thisClientId;
                playersTeam1 = 0;
                playersTeam2 = 0;
                for (int j = 1; j < connected_clients + 1; j++)
                {
                    if (clients[j].tim == 1)
                        playersTeam1++;
                    if (clients[j].tim == 2)
                        playersTeam2++;
                }

                for (int j = 1; j < connected_clients + 1; j++)
                {
                    if(clients[j].tim == 1)
                        if (clients[j].teamID == -1)
                        {
                            clients[j].teamID = id1;
                            listBox1.Invoke((MethodInvoker)(() => listBox1.Items.Add("Client with id " + thisClientId + " " + id1)));

                            id1++;
                            break;
                        }
                }
                for (int j = 1; j < connected_clients + 1; j++)
                {
                    if(clients[j].tim == 2)
                        if (clients[j].teamID == -1 )
                        {
                            clients[j].teamID = id2;
                            listBox1.Invoke((MethodInvoker)(() => listBox1.Items.Add("Client with id " + thisClientId + " " + id2)));
                            id2++;
                            break;
                        }
                }
                updateClientList();
            }

            int i;

            while ((i = clients[thisClientId].stream.Read(bytes, 0, bytes.Length)) != 0)
            {
                data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);
                if (data.StartsWith("username=") && !clients[thisClientId].verified)
                {
                    string newData = data.Replace("username=", "");
                    //string strID = newData.Substring(0, 1);
                    //int clientID = int.Parse(strID);
                    int clientID = thisClientId;
                    //string username = newData.Replace(strID + "=", "");
                    clients[clientID].name = newData;
                    clients[clientID].verified = true;
                    updateClientList();
                }
                else if (!data.StartsWith("username=") && !clients[thisClientId].verified)
                {
                    clients[thisClientId].Pota = true;
                }
                if (data.StartsWith("chat="))
                {
                    if (clients[thisClientId].verified)
                    {
                        string message = data.Replace("chat=", "");
                        //int opponentID = -1;
                        //int offset = thisClientId % 2;
                        //opponentID = (thisClientId % 2) == 1 ? thisClientId + offset : thisClientId - 1;

                        for (int j = 1; j < maxClients; j++)
                        {
                            string textToSend = data;
                            byte[] bytesToSend = ASCIIEncoding.ASCII.GetBytes(textToSend);
                            if (clients[j].stream != null)
                                clients[j].stream.Write(bytesToSend, 0, bytesToSend.Length);
                        }
                    }
                }
                if (data.Contains("disconnect="))
                {
                    string newData = data.Replace("disconnect=", "");
                    //int clientID = int.Parse(newData);
                    int clientID = thisClientId;
                    if (clients[clientID].verified)
                    {
                        listBox1.Invoke((MethodInvoker)(() => listBox1.Items.Add("Client with id " + clientID + " disconnected from the Server!")));
                        listBox1.Invoke((MethodInvoker)(() => listBox1.SelectedIndex = listBox1.Items.Count - 1));
                        clients[clientID].connected = false;
                        clients[clientID].ready = false;
                        clients[clientID].id = -1;
                        clients[clientID].verified = false;
                        clients[clientID].Pota = false;
                        clients[clientID].name = "";
                        if (clients[clientID].tim == 1)
                            id1--;
                        if (clients[clientID].tim == 2)
                            id2--;
                        if (game.game_started)
                        {
                            string textToSend = "opponentDisconnected";
                            byte[] bytesToSend = ASCIIEncoding.ASCII.GetBytes(textToSend);
                            for (int j = 1; j < connected_clients + 1; j++)
                                clients[j].stream.Write(bytesToSend, 0, bytesToSend.Length);
                            game.id = -1;
                            game.game_started = false;
                            for (int j = 1; j < connected_clients + 1; j++)
                            {
                                if (clients[j].connected && clients[j].verified)
                                {
                                    clients[j].ready = false;
                                    clients[j].inGame = false;
                                    clients[j].teamID = -1;
                                }
                            }
                            game.setTurn = true;
                            started_games--;
                            for (int j = 0; j < 3; j++)
                            {
                                for (int k = 0; k < 3; k++)
                                {
                                    game._board[j, k] = Token.Empty;
                                }
                            }
                        }
                        client.Close();
                        updateClientList();
                        updateGameList();
                        connected_clients--;
                        if (connected_clients == 0)
                            label2.Invoke((MethodInvoker)(() => label2.Text = "Waiting for a connection..."));
                        label4.Invoke((MethodInvoker)(() => label4.Text = "" + connected_clients));
                        playerturnlabel.Invoke((MethodInvoker)(() => playerturnlabel.Text = ""));
                        threadsArray[clientID].Join();
                    }
                }
                if (data.Contains("ready="))
                {
                    string newData = data.Replace("ready=", "");
                    //int clientID = int.Parse(newData);
                    int clientID = thisClientId;
                    if (clients[clientID].verified)
                    {
                        clients[clientID].ready = true;
                        updateClientList();
                        updateGameList();
                    }
                }
                //for (int game = 0; game < started_games; game++)
                {
                    if (data.Contains("update=") && game.game_started)
                    {
                        string newData = data.Replace("update=", "");
                        int index = newData.IndexOf("=");
                        string strID = newData.Substring(0, 1);
                        //int clientID = int.Parse(strID);
                        int clientID = thisClientId;
                        if (clients[clientID].verified)
                        {
                            //if (clientID == games[game].playerID1 || clientID == games[game].playerID2)
                            {
                                newData = newData.Remove(0, 1 + index);
                                //listBox1.Invoke((MethodInvoker)(() => listBox1.Items.Add("dada " + newData)));
                                string textToSend = "update=" + newData;
                                byte[] bytesToSend = ASCIIEncoding.ASCII.GetBytes(textToSend);
                                for(int j=1;j<connected_clients+1;j++)
                                  clients[j].stream.Write(bytesToSend, 0, bytesToSend.Length);

                                string id = newData.Substring(0, 1);
                                newData = newData.Remove(0, 1);
                                string status = newData;
                                if (id.Contains("0"))
                                {
                                    if (status.Contains("zero"))
                                    {
                                        game._board[0, 0] = Token.O;
                                    }
                                    if (status.Contains("cross"))
                                    {
                                        game._board[0, 0] = Token.X;
                                    }
                                    if (status.Contains("none"))
                                    {
                                        game._board[0, 0] = Token.Empty;
                                    }
                                }
                                if (id.Contains("1"))
                                {
                                    if (status.Contains("zero"))
                                    {
                                        game._board[0, 1] = Token.O;
                                    }
                                    if (status.Contains("cross"))
                                    {
                                        game._board[0, 1] = Token.X;
                                    }
                                    if (status.Contains("none"))
                                    {
                                        game._board[0, 1] = Token.Empty;
                                    }
                                }
                                if (id.Contains("2"))
                                {
                                    if (status.Contains("zero"))
                                    {
                                        game._board[0, 2] = Token.O;
                                    }
                                    if (status.Contains("cross"))
                                    {
                                       game._board[0, 2] = Token.X;
                                    }
                                    if (status.Contains("none"))
                                    {
                                       game._board[0, 2] = Token.Empty;
                                    }
                                }
                                if (id.Contains("3"))
                                {
                                    if (status.Contains("zero"))
                                    {
                                       game._board[1, 0] = Token.O;
                                    }
                                    if (status.Contains("cross"))
                                    {
                                       game._board[1, 0] = Token.X;
                                    }
                                    if (status.Contains("none"))
                                    {
                                       game._board[1, 0] = Token.Empty;
                                    }
                                }
                                if (id.Contains("4"))
                                {
                                    if (status.Contains("zero"))
                                    {
                                       game._board[1, 1] = Token.O;
                                    }
                                    if (status.Contains("cross"))
                                    {
                                       game._board[1, 1] = Token.X;
                                    }
                                    if (status.Contains("none"))
                                    {
                                       game._board[1, 1] = Token.Empty;
                                    }
                                }
                                if (id.Contains("5"))
                                {
                                    if (status.Contains("zero"))
                                    {
                                       game._board[1, 2] = Token.O;
                                    }
                                    if (status.Contains("cross"))
                                    {
                                       game._board[1, 2] = Token.X;
                                    }
                                    if (status.Contains("none"))
                                    {
                                       game._board[1, 2] = Token.Empty;
                                    }
                                }
                                if (id.Contains("6"))
                                {
                                    if (status.Contains("zero"))
                                    {
                                       game._board[2, 0] = Token.O;
                                    }
                                    if (status.Contains("cross"))
                                    {
                                       game._board[2, 0] = Token.X;
                                    }
                                    if (status.Contains("none"))
                                    {
                                       game._board[2, 0] = Token.Empty;
                                    }
                                }
                                if (id.Contains("7"))
                                {
                                    if (status.Contains("zero"))
                                    {
                                       game._board[2, 1] = Token.O;
                                    }
                                    if (status.Contains("cross"))
                                    {
                                       game._board[2, 1] = Token.X;
                                    }
                                    if (status.Contains("none"))
                                    {
                                       game._board[2, 1] = Token.Empty;
                                    }
                                }
                                if (id.Contains("8"))
                                {
                                    if (status.Contains("zero"))
                                    {
                                       game._board[2, 2] = Token.O;
                                    }
                                    if (status.Contains("cross"))
                                    {
                                       game._board[2, 2] = Token.X;
                                    }
                                    if (status.Contains("none"))
                                    {
                                       game._board[2, 2] = Token.Empty;
                                    }
                                }
                                Console.WriteLine("Game " + game.id + ":");
                                for (int k = 0; k <game._board.GetLength(0); k++)
                                {
                                    for (int j = 0; j <game._board.GetLength(1); j++)
                                    {
                                        Console.Write(game._board[k, j] + "\t");
                                    }
                                    Console.WriteLine();
                                }
                            }
                            updateGameList();
                        }
                    }
                    if (data.StartsWith("nextTurn=") && game.game_started)
                    {
                        string newData = data.Replace("nextTurn=", "");
                        string strID = newData.Substring(0, 1);
                        //int clientID = int.Parse(strID);
                        int clientID = thisClientId;
                        if (clients[clientID].verified)
                        {
                            if (game.game_started)
                            {
                                playersTeam1 = 0;
                                playersTeam2 = 0;
                                for (int j = 1; j < connected_clients; j++)
                                {
                                    if (clients[j].tim == 1)
                                        playersTeam1++;
                                    if (clients[j].tim == 2)
                                        playersTeam2++;
                                }
                                game.playerTurnO = (game.playerTurnO + 1) % (connected_clients + 1);
                                if (game.playerTurnO == 0)
                                    game.playerTurnO++;
                                game.playerTurnX = (game.playerTurnX + 1) % (connected_clients + 1);
                                if (game.playerTurnX == 0)
                                    game.playerTurnX++;
                                string textToSend = "turn=" + game.playerTurnO + "=" + game.playerTurnX;
                                byte[] bytesToSend = ASCIIEncoding.ASCII.GetBytes(textToSend);
                                Thread.Sleep(1000);
                                for(int j = 1; j < connected_clients + 1; j++)
                                    clients[j].stream.Write(bytesToSend, 0, bytesToSend.Length);
                            }
                            updateGameList();
                        }
                    }
                }
                if (clients[thisClientId].verified)
                {
                    listBox1.Invoke((MethodInvoker)(() => listBox1.Items.Add("[" + thisClientId + "]: " + data)));
                    listBox1.Invoke((MethodInvoker)(() => listBox1.SelectedIndex = listBox1.Items.Count - 1));
                }
                else if (clients[thisClientId].Pota)
                {
                    listBox1.Invoke((MethodInvoker)(() => listBox1.Items.Add("Bravo Pota!")));
                    listBox1.Invoke((MethodInvoker)(() => listBox1.SelectedIndex = listBox1.Items.Count - 1));
                    int clientID = thisClientId;
                    listBox1.Invoke((MethodInvoker)(() => listBox1.Items.Add("Client with id " + clientID + " disconnected from the Server!")));
                    listBox1.Invoke((MethodInvoker)(() => listBox1.SelectedIndex = listBox1.Items.Count - 1));
                    clients[clientID].connected = false;
                    clients[clientID].ready = false;
                    clients[clientID].id = -1;
                    /*
                    int gameID = clients[clientID].gameID;
                    if (gameID != -1 && games[gameID].game_started)
                    {
                        string textToSend = "opponentDisconnected";
                        byte[] bytesToSend = ASCIIEncoding.ASCII.GetBytes(textToSend);
                        for(int j = 1; j < connected_clients + 1; j++)
                            clients[j].stream.Write(bytesToSend, 0, bytesToSend.Length);
                        game.id = -1;
                        game.game_started = false;
                        games[gameID].setTurn = true;
                        started_games--;
                    }*/
                    client.Close();
                    updateClientList();
                    updateGameList();
                    connected_clients--;
                    if (connected_clients == 0)
                        label2.Invoke((MethodInvoker)(() => label2.Text = "Waiting for a connection..."));
                    label4.Invoke((MethodInvoker)(() => label4.Text = "" + connected_clients));
                    playerturnlabel.Invoke((MethodInvoker)(() => playerturnlabel.Text = ""));
                    threadsArray[clientID].Join();
                }
            }

            client.Close();
        }

        public Thread StartTheThread(TcpClient obj)
        {
            var t = new Thread(() => HandleClient(obj));
            t.IsBackground = true;
            t.Start();
            return t;
        }

        void serverListen()
        {
            server = new TcpListener(localAddr, port);
            server.Start();
            while (server_started)
            {
                try
                {
                    if (connected_clients == 0)
                        label2.Invoke((MethodInvoker)(() => label2.Text = "Waiting for a connection..."));
                    else
                        label2.Invoke((MethodInvoker)(() => label2.Text = "Clients connected."));
                    if (connected_clients < maxClients)
                    {
                        TcpClient client = server.AcceptTcpClient();
                        if (client.Connected)
                        {
                            connected_clients++;
                            label4.Invoke((MethodInvoker)(() => label4.Text = "" + connected_clients));
                            threadsArray[connected_clients] = StartTheThread(client);
                        }
                    }
                    else
                    {
                        TcpClient client = server.AcceptTcpClient();
                        NetworkStream stream;
                        stream = client.GetStream();
                        string textToSend = "full";
                        byte[] bytesToSend = ASCIIEncoding.ASCII.GetBytes(textToSend);
                        stream.Write(bytesToSend, 0, bytesToSend.Length);
                        stream.Close();
                        client.Close();
                    }

                }
                catch
                {

                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(Environment.ExitCode);

            /*if (server_started)
            {
                server.Stop();
                server_started = false;
                server_thread.Join();
            }*/
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (server_started)
            {
                listBox1.Items.Clear();
                server.Stop();
                server_started = false;
                server_thread.Join();
                label2.Text = "Offline";
                init();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            clients[1].ready = false;
            clients[2].ready = false;
            readyPlayer1.Invoke((MethodInvoker)(() => readyPlayer1.Text = "No"));
            readyPlayer2.Invoke((MethodInvoker)(() => readyPlayer2.Text = "No"));
            string textToSend = "reset";
            byte[] bytesToSend = ASCIIEncoding.ASCII.GetBytes(textToSend);
            if (clients[1].connected)
                clients[1].stream.Write(bytesToSend, 0, bytesToSend.Length);
            if (clients[2].connected)
                clients[2].stream.Write(bytesToSend, 0, bytesToSend.Length);
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    _board[i, j] = Token.Empty;
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            updateClientList();
        }

        private void gameSelection_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.Handle != null)
                updateGameList();
        }
    }
}
